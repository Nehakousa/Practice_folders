const mysql=require('mysql');
const express=require('express');
const cors=require('cors');
var app=express();
const bodyparser=require('body-parser');

app.use(cors());
app.use(bodyparser.json(),(req,res,next)=>{
    next();
});

var mysqlConnection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'password',
    database:'employee'
});

mysqlConnection.connect((err)=>{
    if(!err)
    console.log('DB CONNECTION SUCCESSFULL');
    else
    console.log('DB Connection failed \n Error' + JSON.stringify(err,undefined,2));
});



//To create a new data

app.post('/create',(req,res)=>{
    
    let sql=`insert into users(empid,name,empcode,salary)
            values('${req.body.empid}','${req.body.name}','${req.body.empcode}','${req.body.salary}')`

            mysqlConnection.query(sql,(err,result)=>{
                if(err) throw err;
                else{
                    res.send('data inserted');
                }
            });
});

//it fetches all employees

app.get('/employees' , (req,res)=>{
    mysqlConnection.query('SELECT * FROM users',(err,rows,feilds)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);

    });

});



//fetches a record according to specified id
app.get('/employees/:id' , (req,res)=>{
    mysqlConnection.query('SELECT * FROM users where empid =?',[req.params.id],(err,rows,feilds)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);

    });
});

//updating single data

app.put('/update/:id',(req,res)=>{
    let sql=`update users set name='${req.body.name}' , empcode='${req.body.empcode}',salary='${req.body.salary}'  where empid=${req.params.id}`

    mysqlConnection.query(sql,(err,rows,feilds)=>{
        if(err)
        console.log(err);
        else
        res.send('Data is updated');
    });
});
// Delete a data

app.delete('/remove/:id',(req,res)=>{
    let sql=`delete from users where empid='${req.params.id}'`
    mysqlConnection.query(sql,(err,rows,feilds)=>{
        if(!err) 
        res.send("Record deleted")
        else
        console.log(err)
    });
})


app.listen(5000,()=>console.log(' server listening on port 5000'));