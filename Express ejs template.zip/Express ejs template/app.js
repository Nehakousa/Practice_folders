const express=require('express');
const app=express()

//listen for requests
app.listen(4000,()=>{'server listening on 4000'});

//register view engine
app.set('view engine','ejs');

app.use('/public' , express.static('public'))  

  

const blogs=[
    {title:'Express' , Description:'It is a node js framework'},
    {title:'Nodejs', Description:'It is server side scripting language'},
    {title:'Angular', Description:'It is used to develop single page application'}]


app.get('/',(req,res)=>{
   res.render('index',{name:'neha',blogs});
});

app.get('/login',(req,res)=>{
   
    res.render('login',{name:'neha'});
});












// app.use((req,res,next)=>{
//     console.log("new request")
//     console.log('host :',req.hostname);
//     console.log('path :',req.path);
//     console.log('method :',req.method)
//     next();
// });
  